var indexSectionsWithContent =
{
  0: "bcdefhilmstvw",
  1: "bcdefhilmstvw"
};

var indexSectionNames =
{
  0: "all",
  1: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Pages"
};

