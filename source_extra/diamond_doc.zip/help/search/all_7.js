var searchData=
[
  ['licensing',['Licensing',['../license.html',1,'']]]
];
