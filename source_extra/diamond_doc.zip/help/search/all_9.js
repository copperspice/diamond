var searchData=
[
  ['search',['Search',['../menu-search.html',1,'menus']]],
  ['settings',['Settings',['../menu-settings.html',1,'menus']]]
];
