var searchData=
[
  ['compile_20_26_20link',['Compile &amp; Link',['../build-diamond.html',1,'build']]],
  ['copperspice',['CopperSpice',['../copperspice.html',1,'']]]
];
