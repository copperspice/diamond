var searchData=
[
  ['building',['Building',['../build.html',1,'']]],
  ['building_20for_20os_20x',['Building for OS X',['../build-mac.html',1,'build']]],
  ['building_20for_20windows',['Building for Windows',['../build-win.html',1,'build']]],
  ['building_20for_20x11',['Building for X11',['../build-x11.html',1,'build']]]
];
