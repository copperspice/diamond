var searchData=
[
  ['faq',['FAQ',['../faq.html',1,'']]],
  ['features',['Features',['../features.html',1,'']]],
  ['file',['File',['../menu-file.html',1,'menus']]]
];
