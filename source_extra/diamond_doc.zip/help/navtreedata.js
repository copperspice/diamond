var NAVTREE =
[
  [ "Diamond Editor", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "Installing", "install.html", "install" ],
    [ "Building", "build.html", "build" ],
    [ "Features", "features.html", null ],
    [ "How To", "how_to.html", null ],
    [ "Menus", "menus.html", "menus" ],
    [ "CopperSpice", "copperspice.html", null ],
    [ "FAQ", "faq.html", null ],
    [ "Licensing", "license.html", null ],
    [ "Timeline", "timeline.html", null ],
    [ "Support", "^http://www.sourceforge.net/p/copperspice/discussion-diamond", null ]
  ] ]
];

var NAVTREEINDEX =
[
"build-diamond.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';