var install =
[
    [ "Download Binary", "install-binaries.html", null ],
    [ "Download Source", "install-source.html", null ]
];