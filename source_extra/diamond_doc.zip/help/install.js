var install =
[
    [ "Download Program", "install-binaries.html", null ],
    [ "Download Source", "install-source.html", null ]
];