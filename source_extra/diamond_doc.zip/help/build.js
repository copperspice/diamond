var build =
[
    [ "Compile & Link", "build-diamond.html", null ],
    [ "Building for OS X", "build-mac.html", null ],
    [ "Building for Windows", "build-win.html", null ],
    [ "Building for X11", "build-x11.html", null ]
];