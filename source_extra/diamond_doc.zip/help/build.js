var build =
[
    [ "Building for X11", "require-x11.html", null ],
    [ "Building for Windows", "require-win.html", null ],
    [ "Building for OS X", "require-mac.html", null ],
    [ "Compile & Link", "build-diamond.html", null ]
];