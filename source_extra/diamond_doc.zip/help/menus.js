var menus =
[
    [ "File", "menu-file.html", null ],
    [ "Edit", "menu-edit.html", null ],
    [ "Search", "menu-search.html", null ],
    [ "View", "menu-view.html", null ],
    [ "Document", "menu-document.html", null ],
    [ "Tools", "menu-tools.html", null ],
    [ "Settings", "menu-settings.html", null ],
    [ "Window", "menu-window.html", null ],
    [ "Help", "menu-help.html", null ]
];