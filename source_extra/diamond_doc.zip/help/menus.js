var menus =
[
    [ "Document", "menu-document.html", null ],
    [ "Edit", "menu-edit.html", null ],
    [ "File", "menu-file.html", null ],
    [ "Help", "menu-help.html", null ],
    [ "Search", "menu-search.html", null ],
    [ "Settings", "menu-settings.html", null ],
    [ "Tools", "menu-tools.html", null ],
    [ "View", "menu-view.html", null ],
    [ "Window", "menu-window.html", null ]
];